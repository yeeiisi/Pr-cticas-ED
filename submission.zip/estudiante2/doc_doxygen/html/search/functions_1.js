var searchData=
[
  ['maxstack_0',['MaxStack',['../classMaxStack.html#a1c547b5aa96407f62e7290dca83989d7',1,'MaxStack']]]
];
