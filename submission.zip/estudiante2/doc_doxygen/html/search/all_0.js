var searchData=
[
  ['2_20tda_20maxstack_0',['Minipráctica 2 - TDA MaxStack',['../index.html',1,'']]]
];
