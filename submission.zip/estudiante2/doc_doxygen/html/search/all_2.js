var searchData=
[
  ['comparar_0',['Comparar',['../structComparar.html',1,'']]],
  ['con_20máximo_3a_1',['Pila con máximo:',['../index.html#autotoc_md2',1,'']]]
];
