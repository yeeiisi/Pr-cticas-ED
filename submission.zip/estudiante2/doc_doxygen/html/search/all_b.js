var searchData=
[
  ['size_0',['size',['../classMaxStack.html#ab5793ca38a98af44e031002616b54af3',1,'MaxStack']]]
];
