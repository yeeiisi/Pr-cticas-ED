var searchData=
[
  ['tda_20maxstack_0',['tda maxstack',['../index.html',1,'Minipráctica 2 - TDA MaxStack'],['../repMaxStack.html',1,'Representación del TDA MaxStack .']]],
  ['top_1',['top',['../classMaxStack.html#ac4f51c60565f9eda0d2af150d977c5bb',1,'MaxStack']]]
];
