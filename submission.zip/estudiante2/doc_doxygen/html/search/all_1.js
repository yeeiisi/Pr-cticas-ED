var searchData=
[
  ['abstracción_0',['Función de abstracción',['../repMaxStack.html#faMaxStack',1,'']]]
];
