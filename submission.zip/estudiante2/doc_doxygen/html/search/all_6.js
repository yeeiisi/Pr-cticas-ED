var searchData=
[
  ['introducción_0',['Introducción',['../index.html#autotoc_md0',1,'']]],
  ['invariante_20de_20la_20representación_1',['Invariante de la representación.',['../repMaxStack.html#invMaxStack',1,'']]]
];
