var searchData=
[
  ['tda_20maxstack_0',['tda maxstack',['../index.html',1,'Minipráctica 2 - TDA MaxStack'],['../repMaxStack.html',1,'Representación del TDA MaxStack .']]]
];
