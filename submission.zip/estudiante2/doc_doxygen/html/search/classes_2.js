var searchData=
[
  ['maxstack_0',['MaxStack',['../classMaxStack.html',1,'']]]
];
