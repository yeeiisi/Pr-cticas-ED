#include <iostream>
#include "../include/maxstack.h"

using namespace std;

ostream& operator<<(ostream& salida, element elemento){
    salida << elemento.value << "," << elemento.maximum << "\n";
    return salida;
}

int main(int argc, char *argv[]){

    // Run the current exercise
    MaxStack stack;

    for(int i = 1; i < argc; i++){
        if (argv[i][0] == '.'){
            cout << stack.top() << endl;
            stack.pop();
        }
        else{
            stack.push(atoi(argv[i]));
        }
    }
    return 0;
}
