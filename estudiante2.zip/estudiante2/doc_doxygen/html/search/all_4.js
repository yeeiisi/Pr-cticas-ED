var searchData=
[
  ['ejecutables_0',['Ejecutables',['../index.html#autotoc_md1',1,'']]],
  ['element_1',['element',['../structelement.html',1,'']]],
  ['empty_2',['empty',['../classMaxStack.html#aba0884643ceeb60459d761d1124611bc',1,'MaxStack']]]
];
