var searchData=
[
  ['empty_0',['empty',['../classMaxStack.html#aba0884643ceeb60459d761d1124611bc',1,'MaxStack']]]
];
