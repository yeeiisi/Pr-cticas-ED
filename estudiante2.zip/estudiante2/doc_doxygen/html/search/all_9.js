var searchData=
[
  ['pila_20con_20máximo_3a_0',['Pila con máximo:',['../index.html#autotoc_md2',1,'']]],
  ['pop_1',['pop',['../classMaxStack.html#ab1498f141850cbf2ce83873fa0551747',1,'MaxStack']]],
  ['push_2',['push',['../classMaxStack.html#a5bc8378fe3d77b9689446ce0f8bd5ac6',1,'MaxStack']]]
];
