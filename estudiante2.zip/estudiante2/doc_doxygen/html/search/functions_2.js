var searchData=
[
  ['pop_0',['pop',['../classMaxStack.html#ab1498f141850cbf2ce83873fa0551747',1,'MaxStack']]],
  ['push_1',['push',['../classMaxStack.html#a5bc8378fe3d77b9689446ce0f8bd5ac6',1,'MaxStack']]]
];
