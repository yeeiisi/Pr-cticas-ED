var searchData=
[
  ['representación_0',['Invariante de la representación.',['../repMaxStack.html#invMaxStack',1,'']]],
  ['representación_20del_20tda_20maxstack_1',['Representación del TDA MaxStack .',['../repMaxStack.html',1,'']]]
];
