var searchData=
[
  ['título_20de_20la_20página_20principal_0',['Título de la página principal',['../index.html',1,'']]],
  ['tda_20maxstack_1',['Representación del TDA MaxStack .',['../repMaxStack.html',1,'']]]
];
