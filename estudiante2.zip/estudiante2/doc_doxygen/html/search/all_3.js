var searchData=
[
  ['de_20abstracción_0',['Función de abstracción',['../repMaxStack.html#faMaxStack',1,'']]],
  ['de_20la_20representación_1',['Invariante de la representación.',['../repMaxStack.html#invMaxStack',1,'']]],
  ['del_20tda_20maxstack_2',['Representación del TDA MaxStack .',['../repMaxStack.html',1,'']]]
];
