var searchData=
[
  ['función_20de_20abstracción_0',['Función de abstracción',['../repMaxStack.html#faMaxStack',1,'']]]
];
