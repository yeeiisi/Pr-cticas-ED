var searchData=
[
  ['maxstack_0',['maxstack',['../index.html',1,'Minipráctica 2 - TDA MaxStack'],['../repMaxStack.html',1,'Representación del TDA MaxStack .']]],
  ['minipráctica_202_20tda_20maxstack_1',['Minipráctica 2 - TDA MaxStack',['../index.html',1,'']]]
];
